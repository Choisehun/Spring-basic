package com.peisia.controller.mi.mapper;

import java.util.List;

import com.peisia.controller.mi.guestDto.guestDto;

public interface guestMapper {
	public List<guestDto> getList();
	public guestDto read(long bno);
}



