package com.peisia.controller.mi.guestDto;


import lombok.Data;

@Data
public class guestDto {
	public Long bno;
	public String btext;

}
