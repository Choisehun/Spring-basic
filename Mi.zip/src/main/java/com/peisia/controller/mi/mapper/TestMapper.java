package com.peisia.controller.mi.mapper;


import com.peisia.controller.mi.Dto.TestDto;

public interface TestMapper {
	public TestDto getData1();
	public TestDto getData2();
	public TestDto getData3();
	public TestDto getData4();
	public void updateVisitantCount();
	public void insertaa();
	public void updatedelete();
	
}

