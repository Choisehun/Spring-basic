package com.peisia.controller.service;

import java.util.List;

import com.peisia.controller.mi.guestDto.guestDto;

public interface guestService {
	public List<guestDto> getList();
	public guestDto read(long bno);


	

}
