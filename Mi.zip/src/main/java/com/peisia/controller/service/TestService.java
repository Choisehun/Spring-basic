package com.peisia.controller.service;

public interface TestService {
	public String getOne();
	public String getTwo();

	public void updateVisitantCount();
	public void insertaa();
	public void updatedelete();
}