package com.peisia.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.controller.mi.guestDto.guestDto;
import com.peisia.controller.mi.mapper.guestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class guestServicemp implements guestService{

	@Setter(onMethod_ = @Autowired)
	private guestMapper mapper;	
	
	@Override
	public List<guestDto> getList() {
		log.info("비지니스 계층===========");
		return mapper.getList();
	}
	
	@Override
	public guestDto read(long bno) {
		log.info("guestServicemp read==========");
		return mapper.read(bno);
		
	}

	

}



