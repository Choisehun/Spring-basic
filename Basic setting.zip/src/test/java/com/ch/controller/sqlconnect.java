package com.ch.controller;

import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class sqlconnect {
	Connection con;
	String URL = "jdbc:mysql://localhost:3306/my_cat";
	String id = "root";
	String pw = "0000";
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void connect() {
		try {
			con=DriverManager.getConnection(URL,id,pw);
			log.info("DB접속");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

}
